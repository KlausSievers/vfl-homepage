/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package de.siewares.vfl.entity;

import java.util.Date;
import java.util.Properties;
import java.util.UUID;

/**
 *
 * @author Sievers
 */
public class MagazineMetadata extends DocumentMetadata{
  
   public static final String PROP_ISSUE = "issue";
   
  protected int issue;

  public MagazineMetadata() {
    super();
  }

  public MagazineMetadata(String fileName, Date documentDate, String personName, int issue) {
    this(UUID.randomUUID().toString(), fileName, documentDate, personName, issue);
  }

  public MagazineMetadata(String uuid, String fileName, Date documentDate, String personName, int issue) {
    super(uuid, fileName, documentDate, personName);
    this.issue = issue;
  }

  public MagazineMetadata(Properties properties) {
    super(properties);
    this.issue = Integer.parseInt(properties.getProperty(PROP_ISSUE));
  }

  public int getIssue() {
    return issue;
  }

  public void setIssue(int issue) {
    this.issue = issue;
  }

  @Override
  public Properties createProperties() {
     Properties properties = super.createProperties(); 
     properties.setProperty(PROP_ISSUE, Integer.toString(this.issue));
     return properties;
  }

  
  
  
  
  
}
